﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace watics.classes
{
    public class Entity
    {
        public int CurXPos { get; set; }
        public int CurYPos { get; set; }

        public Status status { get; set; }
        private const int NORMAL = 0, SMASH = 1, GUARD = 2, WAIT = 3;

        public Entity()
        {
            CurXPos = 1;
            CurYPos = 1;
        }

        public Entity(int x, int y)
        {
            CurXPos = x;
            CurYPos = y;

        }

        public Entity(int x, int y, Status stat)
        {
            CurXPos = x;
            CurYPos = y;
            status = stat;
        }

        public Entity(Status stat)
        {
            status = stat;
        }

        private void eliminate()
        {

        }

        public void attack(Entity e)
        {
            status.CurHealthPoint -= e.status.getAttackDamage();
            if (status.CurHealthPoint <= 0)
                eliminate();
        }

        public void attack(Entity e, int actionType)
        {
            switch (actionType)
            {
                case NORMAL:

                    break;
                case SMASH:
                    break;
                case GUARD:
                    break;
                case WAIT:
                    this.status.Heal(status.MaxHealthPoint/8);
                    break;
            }
        }

    }
}

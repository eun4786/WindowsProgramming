﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace watics.classes
{
    public class AI
    {
        private const int GOBLIN = 0, ORC = 1, TROLL = 2, ROBIE0821 = 3;
        private const int NORMAL = 0, SMASH = 1, GUARD = 2, WAIT = 3;

        public double[] chance;

        public AI()
        {
            chance = new double[4];
            chance[SMASH] = 0.2;
            chance[GUARD] = 0.1;
            chance[WAIT] = 0.1;
        }
        public AI(int type)
        {
            switch (type)
            {
                case GOBLIN:
                    chance[SMASH] = 0.1;
                    chance[GUARD] = 0.15;
                    chance[WAIT] = 0.2;
                    break;
                case ORC:
                    chance[SMASH] = 0.2;
                    chance[GUARD] = 0.1;
                    chance[WAIT] = 0.1;
                    break;
                case TROLL:
                    chance[SMASH] = 0.3;
                    chance[GUARD] = 0.0;
                    chance[WAIT] = 0.4;
                    break;
                case ROBIE0821:
                    chance[SMASH] = -1.0;
                    chance[GUARD] = -1.0;
                    chance[WAIT] = 1;
                    break;
            }
        }

        public int getAttackType()
        {
            Random rand = new Random();

            double ch;
            for(int i=1; i<=4; i++)
            {
                ch = rand.NextDouble();

                if (ch <= chance[i])
                    return i;
            }

            return 0;
        }
    }
}

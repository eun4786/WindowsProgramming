﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace watics.classes
{
    class Tile
    {
        public string ImgSource{ get; set; }
        public bool IsPassable { get; set; }
    }
}

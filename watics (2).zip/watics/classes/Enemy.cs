﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace watics.classes
{
    public class Enemy : Entity
    {
        public AI ai { get; set; }

        public string name { get; set; }

        public Image Img { get; set; }
        public string goblineImg = "\\resources\\goblin.png";

        private const int GOBLIN=1, ORC=2, TROLL=3, ROBIE0821=4;


        public Enemy()
        {
            name = "Goblin";
            Img = new Image();
            Img.Source = new BitmapImage(new Uri(goblineImg, UriKind.Relative));
            status = new Status();
        }

        public Enemy(int type)
        {
            MessageBox.Show(type + "생성중");
            setInfo(type);
            //ai = setAI(type);
        }

        private AI setAI(int t)
        {
            AI ret=new AI();
            switch (t)
            {
                default:
                    break;
            }
            return ret;
        }

        private void setInfo(int type)
        {
            Img = new Image();
            
            switch (type)
            {
                case GOBLIN:
                    name = "Goblin";
                    Img.Source = new BitmapImage(new Uri(goblineImg, UriKind.Relative));
                    break;
                case ORC:
                    name = "Orc";
                    Img.Source = new BitmapImage(new Uri(goblineImg, UriKind.Relative));
                    break;
                case TROLL:
                    name = "Troll";
                    Img.Source = new BitmapImage(new Uri(goblineImg, UriKind.Relative));
                    break;
                case ROBIE0821:
                    name = "Robie0821";
                    Img.Source = new BitmapImage(new Uri(goblineImg, UriKind.Relative));
                    break;
            }
            status = setStat(type);
        }

        private Status setStat(int t)
        {
            switch (t)
            {
                case GOBLIN:
                    return new Status(10, 10, 3, 3, 3, 3, 3);
                case ORC:
                    return new Status(30, 20, 7, 4, 3, 6, 2);
                case TROLL:
                    return new Status(50, 80, 9, 7, 4, 15, 7);
                case ROBIE0821:
                    return new Status(9999, 9999, 999, 999, 999, 999, 999);
            }
            return new Status();
        }
    }
}

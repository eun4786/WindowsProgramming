﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace watics.classes
{
    public class Player : Entity
    {
        public string name { get; set; }
        
        public Image Img { get; set; }
        public string imgSrc = "\\resources\\player.png";


        public Player()
        {

            name = "John Cena";
            CurXPos = 0; CurYPos = 0;
            Img = new Image();
            Img.Source = new BitmapImage(new Uri(imgSrc, UriKind.Relative));
            status = new Status();
        }

        public Player(int x, int y)
        {

            CurXPos = x; CurYPos = y;
            Img = new Image();
            Img.Source = new BitmapImage(new Uri(imgSrc, UriKind.Relative));
            status = new Status();
        }
    }
}

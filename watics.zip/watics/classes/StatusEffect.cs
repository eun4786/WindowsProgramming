﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace watics.classes
{
    class StatusEffect
    {
        public bool Weakness { get; set; }
        public bool Slowness { get; set; }
        public bool Empowered { get; set; }
        public bool Strenghthen { get; set; }
        public bool Haste { get; set; }
        public bool Poisened { get; set; }

        public int CurrentEffect { get; set; } //비트연산으로 해볼까
    }
}

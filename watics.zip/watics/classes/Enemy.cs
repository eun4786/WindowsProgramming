﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace watics.classes
{
    public class Enemy : Entity
    {
        public AI ai { get; set; }

        public string name { get; set; }

        public Image Img { get; set; }
        public string imgSrc = "\\resources\\goblin.png";
        

        public Enemy()
        {
            name = "Goblin";
            Img = new Image();
            Img.Source = new BitmapImage(new Uri(imgSrc, UriKind.Relative));
            status = new Status();
        }

        public void Status()
        {

        }


        
        public Enemy(int type)
        {
            ai = setAI(type);
        }

        private AI setAI(int t)
        {
            AI ret=new AI();
            switch (t)
            {
                default:
                    break;
            }
            return ret;
        }
        /*
        private Status setStat(int t)
        {
            int str=t*2, vit=t*3, intel=t*4;
            int hp = str * 1+vit*5

            Status ret = new Status();
        }
        */
    }
}

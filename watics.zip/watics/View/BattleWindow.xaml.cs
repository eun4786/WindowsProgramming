﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using watics.classes;

namespace watics.View
{
    /// <summary>
    /// BattleWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class BattleWindow : Window
    {

        public BattleWindow(Player ob)
        {
            InitializeComponent();

            Log.Text += "\n적을 발견!";
        }

        private void AttackButton_Click(object sender, RoutedEventArgs e)
        {
            Log.Text += "\n적을 공격!";
        }

        private void SkillButton_Click(object sender, RoutedEventArgs e)
        {
            Log.Text += "\n스킬 사용!";
        }

        private void ItemButton_Click(object sender, RoutedEventArgs e)
        {
            Log.Text += "\n아이템 사용!";
        }

        private void EscapeButton_Click(object sender, RoutedEventArgs e)
        {
            Log.Text += "\n도주 시도!";
        }
    }
}

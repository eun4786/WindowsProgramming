﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace watics.View.Battle
{
    class StatusBar : ProgressBar
    {
        public DependencyProperty statusBarProperty = DependencyProperty.Register("status", typeof(int), typeof(StatusBar), new PropertyMetadata(OnStatusChanged));

        public int statusBar
        {
            set
            {
                SetValue(statusBarProperty, value);
            }

            get
            {
                return (int)GetValue(statusBarProperty);
            }
        }
        private static void OnStatusChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            
        }
    }
}

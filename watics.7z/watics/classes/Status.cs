﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace watics.classes
{
    public class Status : INotifyPropertyChanged
    {
        private int level;
        private int maxHealthPoint;
        private int curHealthPoint;
        private int maxManaPoint;
        private int curManaPoint;
        private int strength;
        private int dexterity;
        private int intelligence;
        private int vitallity;
        private int luck;

        public int MaxHealthPoint
        {
            get { return maxHealthPoint; }
            set { maxHealthPoint = value; OnPropertyChanged("MaxHealthPoint"); }
        }
        public int CurHealthPoint
        {
            get { return curHealthPoint; }
            set { curHealthPoint = value; OnPropertyChanged("CurHealthPoint"); }
        }
        public int MaxManaPoint
        {
            get { return maxManaPoint; }
            set { maxManaPoint = value; OnPropertyChanged("MaxManaPoint"); }
        }
        public int CurManaPoint
        {
            get { return curManaPoint; }
            set { curManaPoint = value; OnPropertyChanged("CurHealthPoint"); }
        }
        public int Strength
        {
            get { return strength; }
            set { strength = value; OnPropertyChanged("Strength"); }
        }
        public int Dexterity
        {
            get { return dexterity; }
            set { dexterity = value; OnPropertyChanged("Dexterity"); }
        }
        public int Intelligence
        {
            get { return intelligence; }
            set { intelligence = value; OnPropertyChanged("Intelligence"); }
        }
        public int Vitallity
        {
            get { return vitallity; }
            set { vitallity = value; OnPropertyChanged("Vitallity"); }
        }
        public int Luck
        {
            get { return luck; }
            set { luck = value; OnPropertyChanged("Luck"); }
        }

        public int getAttackDamage()
        {
            return strength;
        }

        //public int CurHealthPoint { get; set; }
        //public int ManaPoint { get; set; }
        //public int CurManaPoint { get; set; }
        //public int Strength { get; set; }
        //public int Dexterity { get; set; }
        //public int Intelligence { get; set; }
        //public int Vitallity { get; set; }
        //public int Luck { get; set; }

        public Status()
        {
            MaxHealthPoint = 100;
            CurHealthPoint = 45;
            MaxManaPoint = 100;
            CurManaPoint = 55;

            Strength = 5;
            Dexterity = 5;
            Intelligence = 5;
            Vitallity = 5;
            Luck = 5;
        }

        public Status(int hp, int mp)
        {

        }

        public Status(int hp, int mp, int str, int dex, int intel, int vit, int lck)
        {
            MaxHealthPoint = hp;
            CurHealthPoint = hp;
            MaxManaPoint = mp;
            CurManaPoint = mp;

            strength = str;
            dexterity = dex;
            intelligence = intel;
            vitallity = vit;
            luck = lck;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace watics.classes
{
    public class Entity
    {
        public int CurXPos { get; set; }
        public int CurYPos { get; set; }

        public Status status { get; set; }

        public Entity()
        {
            CurXPos = 1;
            CurYPos = 1;
        }

        public Entity(int x, int y)
        {
            CurXPos = x;
            CurYPos = y;

        }

        public Entity(int x, int y, Status stat)
        {
            CurXPos = x;
            CurYPos = y;
            status = stat;
        }

        public Entity(Status stat)
        {
            status = stat;
        }

        private void eliminate()
        {

        }

        public void attack(Entity e)
        {
            status.CurHealthPoint -= e.status.getAttackDamage();
            if (status.CurHealthPoint <= 0)
                eliminate();
        }

    }
}

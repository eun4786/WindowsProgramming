﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using watics.classes;
using watics.View;

namespace watics
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        string grass = "\\resources\\grass.png";
        string tree = "\\resources\\tree.png";

        private int maxColumn = 15, maxRow = 15;
        //밖으로 뺐음
        private int firstXPos = 8, firstYPos = 7;

        private Tile[,] map;
        private Image[,] tiles;
        private Player player;

        private int counter;

        public MainWindow()
        {
            InitializeComponent();
            initArray(); //배열 초기화
            setTileData(); //타일 정보 설정
            generateTile(); //타일 배치
            setPlayerData();
        }

        private void initArray()
        {
            map = new Tile[maxRow, maxColumn];
            tiles = new Image[maxRow, maxColumn];

            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                    map[i, j] = new Tile();
            }
        }
        
        private void setPlayerData()
        {
            //firstXPos, firstYPos 멤버변수로 뺌
            player = new Player(firstXPos, firstYPos);

            Grid.SetColumn(player.Img, firstXPos);
            Grid.SetRow(player.Img, firstYPos);

            mapGrid.Children.Add(player.Img);
        }

        private void setTileData() //타일 정보 저장
        {
            Random rand = new Random();
            int tmp;
            for (int i = 0; i < maxRow; i++)
            {
                for (int j = 0; j < maxColumn; j++)
                {
                    /*바뀐 부분*/
                    if (i == firstYPos && j == firstXPos)
                        tmp = 0;
                    else
                        tmp = rand.Next(0, 10);
                    /*여기까지*/
                    if (tmp <= 8)
                    {
                        map[i, j].ImgSource = grass;
                        map[i, j].IsPassable = true;
                    }
                    else if (tmp > 8)
                    {
                        map[i, j].ImgSource = tree;
                        map[i, j].IsPassable = false;
                    }
                }
            }
        }

        private void generateTile()
        {
            for (int i = 0; i < maxRow; i++)
            {
                for (int j = 0; j < maxColumn; j++)
                {
                    Image img = new Image();

                    img.Source = new BitmapImage(new Uri(map[i, j].ImgSource, UriKind.Relative)); //상대경로 사용 위해 UriKind.Relative 를 인자로 넘김
                    
                    Grid.SetColumn(img, j); //타일 위치 지정
                    Grid.SetRow(img, i);    //타일 위치 지정

                    tiles[i, j] = img; //타일 정보 배열에 저장

                    mapGrid.Children.Add(img); //윈도우에 타일 추가
                }
            }
        }
        
        private bool canMovable(int x, int y)
        {
            return map[y, x].IsPassable;
        }

        private void movePlayer()
        {
            mapGrid.Children.Remove(player.Img);
            Grid.SetColumn(player.Img, player.CurXPos);
            Grid.SetRow(player.Img, player.CurYPos);

            mapGrid.Children.Add(player.Img);
        }

        //키보드 입력
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            
            int xdir = 0, ydir = 0;
            switch (e.Key)
            {
                case Key.Left:
                    xdir = -1;
                    break;
                case Key.Right:
                    xdir = 1;
                    break;
                case Key.Up:
                    ydir = -1;
                    break;
                case Key.Down:
                    ydir = 1;
                    break;
            }
            //플레이어의 현재 위치(player.CurㅁPos 와 움직이는 방향(xdir,ydir)을 더해서 판단
            //플레이어의 목적지가 갈 수 있는 곳인지 판단
            if (player.CurXPos + xdir >= 0 && player.CurYPos + ydir >= 0 &&player.CurXPos + xdir < 15 && player.CurYPos + ydir < 15 &&
                canMovable(player.CurXPos + xdir, player.CurYPos + ydir))
            {
                Random rand = new Random();
                player.CurXPos += xdir;
                player.CurYPos += ydir;

                //갈 수 있는 곳이면 이동
                movePlayer();
                if(rand.Next(0,10)==0)
                {
                    encounter(); //전투창 열리게 하면 됨
                    counter++;
                }
            }
        }

        private void encounter()
        {
            //여기 들어오면 맵에 있는 객체 아무것도 조작 못하게 막아야됨
            MessageBox.Show("적 발견");

            //TODO : 적 생성해서 스텟주고 인자로 주기

            new BattleWindow(player).ShowDialog();
        }
    }
}
